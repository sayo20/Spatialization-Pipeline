Save here the HRTF data from the FHK database, http://www.audiogroup.web.fh-koeln.de/ku100hrir.html
The data must be in the format as downloaded from the server, i.e., HRIR_*.mat

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
