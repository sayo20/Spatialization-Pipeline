Save here the data from the UMA database (Arcadio Reyes).
The data must be in the .mat format as provided by the University of Malaga.

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
