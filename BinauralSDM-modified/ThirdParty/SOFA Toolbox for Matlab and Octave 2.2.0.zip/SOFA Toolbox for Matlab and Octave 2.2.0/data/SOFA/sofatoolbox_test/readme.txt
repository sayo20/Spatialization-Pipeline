SOFA files go here. They can be

* manually downloaded by you from http://tinyurl.com/sofaHRTFs
* automatically created by the Toolbox by demo_ functions when the source HRTFs are available
* automatically downloaded by the Toolbox from http://www.sofacoustics.org/data/sofatoolbox_test when requested and available

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
