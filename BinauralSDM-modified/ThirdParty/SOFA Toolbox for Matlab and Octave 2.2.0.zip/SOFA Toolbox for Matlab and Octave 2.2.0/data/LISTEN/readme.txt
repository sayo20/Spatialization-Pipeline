Save here the data from the LISTEN database, http://recherche.ircam.fr/equipes/salles/listen/download.html
The data must be in the format as downloaded from IRCAM, that is IRC_XXXX\COMPENSATED\MAT\HRIR\IRC_XXX_C_HRIR.mat where XXXX is the LISTEN subject ID (4 digits).

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
